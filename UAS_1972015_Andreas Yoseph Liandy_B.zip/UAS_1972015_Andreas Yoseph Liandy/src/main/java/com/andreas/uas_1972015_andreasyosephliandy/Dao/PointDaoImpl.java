/**
 * 1972015 Andreas Yoseph Liandy
 */
package com.andreas.uas_1972015_andreasyosephliandy.Dao;

import Entity.FeMemberEntity;
import Entity.FePointEntity;
import com.andreas.uas_1972015_andreasyosephliandy.Util.HibernateUtil;
import javafx.collections.FXCollections;
import org.hibernate.Session;
import org.hibernate.Transaction;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import java.util.List;

public class PointDaoImpl implements DaoInterface<FePointEntity>{
    @Override
    public int addData(FePointEntity data) {
        Session session = HibernateUtil.getSession();
        Transaction t = session.beginTransaction();
        session.save(data);
        t.commit();
        session.close();
        return 0;
    }

    @Override
    public int delData(FePointEntity data) {
        return 0;
    }

    @Override
    public int upData(FePointEntity data) {
        return 0;
    }

    @Override
    public List<FePointEntity> getAll() {
        Session session = HibernateUtil.getSession();
        CriteriaBuilder builder = session.getCriteriaBuilder();
        CriteriaQuery query = builder.createQuery(FePointEntity.class);
        query.from(FePointEntity.class);
        List<FePointEntity> clist = session.createQuery(query).getResultList();
        session.close();
        return FXCollections.observableArrayList(clist);
    }
}
