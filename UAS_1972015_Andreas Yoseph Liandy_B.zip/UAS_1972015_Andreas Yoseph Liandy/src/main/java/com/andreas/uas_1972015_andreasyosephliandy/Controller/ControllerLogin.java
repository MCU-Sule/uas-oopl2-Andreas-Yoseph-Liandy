/**
 * 1972015 Andreas Yoseph Liandy
 */
package com.andreas.uas_1972015_andreasyosephliandy.Controller;

import Entity.FeMemberEntity;
import com.andreas.uas_1972015_andreasyosephliandy.Main;
import com.andreas.uas_1972015_andreasyosephliandy.Util.LoginService;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import org.hibernate.HibernateException;

import java.io.IOException;
import java.util.Locale;

public class ControllerLogin {

    public TextField txtId;
    public PasswordField txtPassword;
    public GridPane gridAndre;

    public void btnLogin(ActionEvent actionEvent) {
        try {
            FeMemberEntity member = LoginService.login(txtId.getText(), (txtPassword.getText().toLowerCase(Locale.ROOT)));
            if (member != null) {
                FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("main-view.fxml"));
                Scene scene = new Scene(fxmlLoader.load());
                Stage hlmLogin = new Stage();
                hlmLogin.setTitle("UAS Andreas Yoseph Liandy");
                hlmLogin.setScene(scene);
                hlmLogin.show();
                Stage stage = ((Stage) gridAndre.getScene().getWindow());
                stage.close();
            }
        } catch (HibernateException | IOException ex) {
            ex.printStackTrace();
        }
    }
}
