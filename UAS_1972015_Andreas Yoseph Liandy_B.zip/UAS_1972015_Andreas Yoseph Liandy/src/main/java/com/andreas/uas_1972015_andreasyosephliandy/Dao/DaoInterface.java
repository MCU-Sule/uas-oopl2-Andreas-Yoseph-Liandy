/**
 * 1972015 Andreas Yoseph Liandy
 */
package com.andreas.uas_1972015_andreasyosephliandy.Dao;

import java.util.List;

public interface DaoInterface <T>{
    public int addData (T data);
    public int delData (T data);
    public int upData (T data);

    List<T> getAll();
}
