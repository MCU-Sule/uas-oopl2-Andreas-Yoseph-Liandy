package com.andreas.uas_1972015_andreasyosephliandy.Dao;

import Entity.FeMemberEntity;
import com.andreas.uas_1972015_andreasyosephliandy.Util.HibernateUtil;
import javafx.collections.FXCollections;
import org.hibernate.Session;
import org.hibernate.Transaction;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import java.util.List;

public class MemberDaoImpl implements DaoInterface<FeMemberEntity> {
    @Override
    public int addData(FeMemberEntity data) {
        Session session = HibernateUtil.getSession();
        Transaction t = session.beginTransaction();
        session.save(data);
        t.commit();
        session.close();
        return 0;
    }

    @Override
    public int delData(FeMemberEntity data) {
        return 0;
    }

    @Override
    public int upData(FeMemberEntity data) {
        Session session = HibernateUtil.getSession();
        Transaction t = session.beginTransaction();
        session.update(data);
        t.commit();
        session.close();
        return 0;
    }

    @Override
    public List<FeMemberEntity> getAll() {
        Session session = HibernateUtil.getSession();
        CriteriaBuilder builder = session.getCriteriaBuilder();
        CriteriaQuery query = builder.createQuery(FeMemberEntity.class);
        query.from(FeMemberEntity.class);
        List<FeMemberEntity> clist = session.createQuery(query).getResultList();
        session.close();
        return FXCollections.observableArrayList(clist);
    }
}
