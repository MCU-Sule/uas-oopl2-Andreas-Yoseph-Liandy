/**
 * 1972015 Andreas Yoseph Liandy
 */
package com.andreas.uas_1972015_andreasyosephliandy.Controller;

import Entity.FeMemberEntity;
import Entity.FePointEntity;
import Entity.FeTransactionEntity;
import com.andreas.uas_1972015_andreasyosephliandy.Dao.MemberDaoImpl;
import com.andreas.uas_1972015_andreasyosephliandy.Dao.PointDaoImpl;
import com.andreas.uas_1972015_andreasyosephliandy.Dao.TransaksiDaoImpl;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.Date;
import java.time.LocalDate;
import java.util.Locale;
import java.util.ResourceBundle;

public class Controller implements Initializable {
    public TextField txtCitizenId;
    public TextField txtName;
    public TextArea txtAddress;
    public TextField txtPhone;
    public TextField txtEmail;
    public TextField txtUsername;
    public DatePicker txtBirthDate;
    public Button btnSave;
    public Button btnReset;
    public Button btnUpdate;
    public TextField txtNominal;
    public DatePicker txtTransactionDate;

    public TableView<FeTransactionEntity> tabelTransaction;
    public TableView<FePointEntity> tabelPoint;
    public TableView<FeMemberEntity> tabelMember;
    public TableColumn<FeMemberEntity, String> kolomCitizenId;
    public TableColumn<FeMemberEntity, String> kolomName;
    public TableColumn <FeMemberEntity, String>kolomPhone;
    public TableColumn <FeMemberEntity, String>kolomBirthDate;

    public TableColumn<FeTransactionEntity,String> kolomTransaksiDate;
    public TableColumn<FeTransactionEntity,String> kolomNominal;

    public TableColumn <FePointEntity,String>kolomId;
    public TableColumn <FePointEntity,String>kolomPoint;
    public ComboBox comboBahasa;

    private ObservableList<FeMemberEntity> memberAndre;
    private ObservableList<FePointEntity> pointAndre;
    private ObservableList<FeTransactionEntity> transaksiAndre;

    public void btnSaveAction(ActionEvent actionEvent) {
        FeMemberEntity member =new FeMemberEntity();
        member.setCitizenId(String.valueOf(txtCitizenId.getText()));
        member.setName(String.valueOf(txtName.getText()));
        member.setPhone(String.valueOf(txtPhone.getText()));
        member.setBirthdate(Date.valueOf(txtBirthDate.getValue()));

        MemberDaoImpl memberDao = new MemberDaoImpl();
        memberDao.addData(member);
        memberAndre.clear();
        memberAndre.addAll(memberDao.getAll());

        tabelMember.refresh();
        txtCitizenId.setText("");
        txtName.setText(null);
        txtPhone.setText(null);
        txtBirthDate.setValue(null);
    }

    public void btnResetAction(ActionEvent actionEvent) {
        txtCitizenId.clear();
        txtName.setText(null);
        txtAddress.setText(null);
        txtPhone.setText(null);
        txtEmail.setText(null);
        txtUsername.setText(null);
        txtBirthDate.setValue(null);
    }

    public void btnUpdateAction(ActionEvent actionEvent) {
        FeMemberEntity member;
        member = tabelMember.getSelectionModel().getSelectedItem();

        member.setName(String.valueOf(txtName.getText()));
        member.setAddress(String.valueOf(txtAddress.getText()));
        member.setPhone(txtPhone.getText());
        member.setEmail(txtEmail.getText());
        member.setUsername(txtUsername.getText());
        member.setBirthdate(Date.valueOf(txtBirthDate.getValue()));

        MemberDaoImpl memberDao = new MemberDaoImpl();
        int result = memberDao.upData(member);
        if (result != 0){
            System.out.println("Data telah Terupdate");
        }
        memberAndre.clear();
        memberAndre.addAll(memberDao.getAll());
        tabelMember.refresh();
        btnSave.setDisable(false);
        btnReset.setDisable(false);
        btnUpdate.setDisable(true);
        txtCitizenId.setDisable(false);
        txtCitizenId.clear();
        txtName.setText(null);
        txtAddress.setText(null);
        txtPhone.setText(null);
        txtEmail.setText(null);
        txtUsername.setText(null);
        txtBirthDate.setValue(null);
    }

    public void btnSaveTransaction(ActionEvent actionEvent) {
        FeTransactionEntity transaksi =new FeTransactionEntity();
        transaksi.setNominal(Integer.valueOf(txtNominal.getText()));
        transaksi.setTransDate(Date.valueOf(txtTransactionDate.getValue()));

        TransaksiDaoImpl transaksiDao =new TransaksiDaoImpl();
        transaksiDao.addData(transaksi);

        tabelTransaction.refresh();
        txtNominal.setText("");
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        MemberDaoImpl memberDao = new MemberDaoImpl();
        TransaksiDaoImpl transaksiDao = new TransaksiDaoImpl();
        PointDaoImpl pointDao = new PointDaoImpl();
        memberAndre = (ObservableList<FeMemberEntity>) memberDao.getAll();
        transaksiAndre = (ObservableList<FeTransactionEntity>) transaksiDao.getAll();
        pointAndre = (ObservableList<FePointEntity>) pointDao.getAll();
        tabelMember.setItems(memberAndre);
        ObservableList<String> list = FXCollections.observableArrayList("English", "Indonesia");
        kolomCitizenId.setCellValueFactory(data->new SimpleStringProperty(String.valueOf(data.getValue().getCitizenId())));
        kolomName.setCellValueFactory(data->new SimpleStringProperty(String.valueOf(data.getValue().getName())));
        kolomPhone.setCellValueFactory(data->new SimpleStringProperty(String.valueOf(data.getValue().getPhone())));
        kolomBirthDate.setCellValueFactory(data->new SimpleStringProperty(String.valueOf(data.getValue().getBirthdate())));
        btnSave.setDisable(false);
        btnUpdate.setDisable(true);
        btnReset.setDisable(false);
        tabelTransaction.setItems(transaksiAndre);
        tabelTransaction.setItems(transaksiAndre);
        kolomNominal.setCellValueFactory(data->new SimpleStringProperty(String.valueOf(data.getValue().getNominal())));
        kolomTransaksiDate.setCellValueFactory(data->new SimpleStringProperty(String.valueOf(data.getValue().getTransDate())));
    }

    public void tableMemberClicked(MouseEvent mouseEvent) {
        FeMemberEntity isi = tabelMember.getSelectionModel().getSelectedItem();
        txtCitizenId.setDisable(true);
        btnSave.setDisable(true);
        btnUpdate.setDisable(false);
        btnReset.setDisable(false);
        txtCitizenId.setText(String.valueOf(tabelMember.getSelectionModel().getSelectedItem().getCitizenId()));
        txtName.setText(String.valueOf(tabelMember.getSelectionModel().getSelectedItem().getName()));
        txtPhone.setText(String.valueOf(tabelMember.getSelectionModel().getSelectedItem().getPhone()));
        txtBirthDate.setValue(LocalDate.parse(String.valueOf(tabelMember.getSelectionModel().getSelectedItem().getBirthdate())));
    }

    public void localeView(Locale locale){
        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("main-view.fxml"));
        fxmlLoader.setResources(ResourceBundle.getBundle("bundle1", locale));
        try {
            Parent root = fxmlLoader.load();
            Stage stage = (Stage) comboBahasa.getScene().getWindow();
            stage.setScene(new Scene(root));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void comboBahasa(ActionEvent actionEvent) {
        String s = comboBahasa.getSelectionModel().getSelectedItem().toString();
        if (s == "Indonesia") {
            Locale l = new Locale("IN");
            localeView(l);
        } else {
            Locale l = new Locale("EN");
            localeView(l);
        }
    }
}