package com.andreas.uas_1972015_andreasyosephliandy.Dao;

import Entity.FeMemberEntity;
import Entity.FeTransactionEntity;
import com.andreas.uas_1972015_andreasyosephliandy.Util.HibernateUtil;
import javafx.collections.FXCollections;
import org.hibernate.Session;
import org.hibernate.Transaction;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import java.util.List;

public class TransaksiDaoImpl implements DaoInterface<FeTransactionEntity> {
    @Override
    public int addData(FeTransactionEntity data) {
        Session session = HibernateUtil.getSession();
        Transaction t = session.beginTransaction();
        session.save(data);
        t.commit();
        session.close();
        return 0;
    }

    @Override
    public int delData(FeTransactionEntity data) {
        return 0;
    }

    @Override
    public int upData(FeTransactionEntity data) {
        return 0;
    }

    @Override
    public List<FeTransactionEntity> getAll() {
        Session session = HibernateUtil.getSession();
        CriteriaBuilder builder = session.getCriteriaBuilder();
        CriteriaQuery query = builder.createQuery(FeTransactionEntity.class);
        query.from(FeTransactionEntity.class);
        List<FeTransactionEntity> clist = session.createQuery(query).getResultList();
        session.close();
        return FXCollections.observableArrayList(clist);
    }
}
