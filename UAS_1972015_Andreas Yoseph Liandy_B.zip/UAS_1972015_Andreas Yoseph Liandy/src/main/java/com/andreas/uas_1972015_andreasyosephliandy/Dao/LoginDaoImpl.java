package com.andreas.uas_1972015_andreasyosephliandy.Dao;

import Entity.FeMemberEntity;
import com.andreas.uas_1972015_andreasyosephliandy.Util.HibernateUtil;
import com.andreas.uas_1972015_andreasyosephliandy.Util.LoginService;
import org.hibernate.HibernateException;
import org.hibernate.Session;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import java.util.function.Predicate;

public class LoginDaoImpl implements LoginService {
    @Override
    public FeMemberEntity login(String email, String password) throws HibernateException {
        Session session = HibernateUtil.getSession();
        CriteriaBuilder criteriaBuilder = session.getCriteriaBuilder();
        CriteriaQuery<FeMemberEntity> criteriaQuery = criteriaBuilder.createQuery(FeMemberEntity.class);
        Root<FeMemberEntity> userRoot = criteriaQuery.from(FeMemberEntity.class);

        Predicate predicateEmail = (Predicate) criteriaBuilder.equal(userRoot.get("email"), email);
        Predicate predicatePassword = (Predicate) criteriaBuilder.equal(userRoot.get("password"), password);
        Predicate predicateAll = criteriaBuilder.and(predicateEmail, predicatePassword);
        criteriaQuery.where(predicateAll);

        FeMemberEntity member = session.createQuery(criteriaQuery).getResultList().get(0);
        session.close();
        return member;
    }
}
