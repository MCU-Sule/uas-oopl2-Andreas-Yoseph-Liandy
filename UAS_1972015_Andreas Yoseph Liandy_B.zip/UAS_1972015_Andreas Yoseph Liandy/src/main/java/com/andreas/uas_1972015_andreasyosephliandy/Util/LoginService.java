package com.andreas.uas_1972015_andreasyosephliandy.Util;
import Entity.FeMemberEntity;
import org.hibernate.HibernateException;

public interface LoginService {
    static FeMemberEntity login(String email, String password) throws HibernateException;
}





