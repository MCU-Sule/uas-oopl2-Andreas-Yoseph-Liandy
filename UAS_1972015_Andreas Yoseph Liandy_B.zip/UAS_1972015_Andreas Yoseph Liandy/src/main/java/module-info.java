module com.andreas.uas_1972015_andreasyosephliandy {
    requires javafx.controls;
    requires javafx.fxml;
    requires org.hibernate.orm.core;
    requires java.sql;
    requires javax.persistence;


    opens com.andreas.uas_1972015_andreasyosephliandy to javafx.fxml;
    exports com.andreas.uas_1972015_andreasyosephliandy;
    exports com.andreas.uas_1972015_andreasyosephliandy.Controller;
    opens com.andreas.uas_1972015_andreasyosephliandy.Controller to javafx.fxml;
}